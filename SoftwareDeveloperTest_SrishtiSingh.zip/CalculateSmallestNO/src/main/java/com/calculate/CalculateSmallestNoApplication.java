package com.calculate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculateSmallestNoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculateSmallestNoApplication.class, args);

	}

}