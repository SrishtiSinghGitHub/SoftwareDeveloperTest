package com.calculate.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SmallestNumber {
	
	
	private long smallestNumber;
	private double timeInCalculating;
	
	
	
	public SmallestNumber() {
		super();
	}

	public SmallestNumber(long smallestNumber, double timeInCalculating) {
		super();
		this.smallestNumber = smallestNumber;
		this.timeInCalculating = timeInCalculating;
	}
	
	public long getSmallestNumber() {
		return smallestNumber;
	}
	public void setSmallestNumber(long smallestNumber) {
		this.smallestNumber = smallestNumber;
	}
	public double getTimeInCalculating() {
		return timeInCalculating;
	}
	public void setTimeInCalculating(double timeInCalculating) {
		this.timeInCalculating = timeInCalculating;
	}
	
	

}
