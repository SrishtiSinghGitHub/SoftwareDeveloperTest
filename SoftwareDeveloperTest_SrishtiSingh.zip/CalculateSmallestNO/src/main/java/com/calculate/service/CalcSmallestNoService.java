package com.calculate.service;

import com.calculate.model.Range;
import com.calculate.model.SmallestNumber;

public interface CalcSmallestNoService {
	
	public Range setTheUpperLimit(long upperLimit);
	
	public SmallestNumber calcSmallestNumber();
	

}
