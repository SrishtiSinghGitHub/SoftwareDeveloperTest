package com.calculate.constants;

public class Constants {
	
	public static long UPPER_LIMIT_CHECK=25;
	public static String SUCCESS_MESSAGE="THE RANGE IS SET SUCCESSFULLY";
	public static String FAILURE_MESSAGE="UPPERRANGE EXCEEDS 25";
	
	public static String FAILURE_STATUS="FAIL";
	public static String SUCCESS_STATUS="SUCCESS";

}
